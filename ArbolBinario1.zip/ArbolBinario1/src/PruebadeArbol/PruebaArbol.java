package PruebadeArbol;

public class PruebaArbol {
    
    public static void main(String[] args){
        Nodo raiz = new Nodo(1);
        Nodo nodo2 = new Nodo(2);
        Nodo nodo3 = new Nodo(3);

        nodo3.setNodoDerecho(new Nodo(6));
        nodo3.setNodoIzquierdo(new Nodo(5));
        
        nodo2.setNodoIzquierdo(new Nodo(4));
        
        raiz.setNodoIzquierdo(nodo2);
        raiz.getNodoDerecho(nodo3);
    }
}
