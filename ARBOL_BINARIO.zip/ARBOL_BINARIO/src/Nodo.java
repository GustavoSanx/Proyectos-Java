
public class Nodo {
    public int numero;
    public Nodo padre;
    public Nodo izquierda;
    public Nodo derecha;
    
    public Nodo(){
        numero=0;
        padre=null;
        izquierda=null;
        derecha=null;
    }

    public Nodo(int numero, Nodo padre, Nodo izquierda, Nodo derecha) {
        this.numero = numero;
        this.padre = padre;
        this.izquierda = izquierda;
        this.derecha = derecha;
    }
    
    
}
