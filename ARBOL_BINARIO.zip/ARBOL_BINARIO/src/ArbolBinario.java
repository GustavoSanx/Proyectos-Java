
public class ArbolBinario {
    
    public Nodo raiz;
    
    public ArbolBinario(){
        raiz=null;
        
    }
    public boolean estaVacia(){
        if(raiz==null){
            return true;        
        }else{
            return false;
        }
    }
    public void agregarNodo(int numero){
        Nodo nuevo= new Nodo(numero,null,null,null);
        if (estaVacia()){
            raiz= nuevo;
            
        }else{
            Nodo temp=raiz;
            while( temp !=null){
                nuevo.padre=temp;
                if(nuevo.numero>=temp.numero){
                    temp=temp.derecha;
                    
                }else
                    temp=temp.izquierda;
            }
            if(nuevo.numero<nuevo.padre.numero){
                nuevo.padre.izquierda= nuevo;
            }else
                nuevo.padre.derecha=nuevo;
            
        }
    }
    
    public void Imprimir(Nodo base){
        if(base !=null){
            Imprimir(base.izquierda);
            System.out.println("Numero: "+base.numero);
            Imprimir(base.derecha);
        }
    }
}
