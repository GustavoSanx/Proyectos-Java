
public class PruebadeArbol {
    
    public static void main(String[] args){
        
        ArbolBinario arbol = new ArbolBinario();
        arbol.agregarNodo(2);
        arbol.agregarNodo(5);
        arbol.agregarNodo(7);
        arbol.agregarNodo(13);
        arbol.agregarNodo(15);
        arbol.agregarNodo(18);
        arbol.agregarNodo(4);
        
        arbol.Imprimir(arbol.raiz);
    }
}
